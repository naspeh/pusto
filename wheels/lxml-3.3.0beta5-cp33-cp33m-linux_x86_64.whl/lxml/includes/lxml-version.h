#ifndef LXML_VERSION_STRING
#define LXML_VERSION_STRING "3.3.0.beta5"
#endif
