lxml is a Pythonic, mature binding for the libxml2 and libxslt libraries.  It
provides safe and convenient access to these libraries using the ElementTree
API.

It extends the ElementTree API significantly to offer support for XPath,
RelaxNG, XML Schema, XSLT, C14N and much more.

To contact the project, go to the `project home page
<http://lxml.de/>`_ or see our bug tracker at
https://launchpad.net/lxml

In case you want to use the current in-development version of lxml,
you can get it from the github repository at
https://github.com/lxml/lxml .  Note that this requires Cython to
build the sources, see the build instructions on the project home
page.  To the same end, running ``easy_install lxml==dev`` will
install lxml from
https://github.com/lxml/lxml/tarball/master#egg=lxml-dev if you have
an appropriate version of Cython installed.

3.3.0beta5 (2014-01-18)
=======================

Features added
--------------

* The PEP 393 unicode parsing support gained a fallback for wchar strings
  which might still be somewhat common on Windows systems.

Bugs fixed
----------

* Several error handling problems were fixed throughout the code base that
  could previously lead to exceptions being silently swallowed or not
  properly reported.

* The C-API function ``appendChild()`` is now deprecated as it does not
  propagate exceptions (its return type is ``void``).  The new function
  ``appendChildToElement()`` was added as a safe replacement.

* Passing a string into ``fromstringlist()`` raises an exception instead of
  parsing the string character by character.

Other changes
-------------

* Document cleanup code was simplified using the new GC features in
  Cython 0.20.




